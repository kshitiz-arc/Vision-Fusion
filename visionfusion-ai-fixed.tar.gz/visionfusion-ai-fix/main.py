#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║        VisionFusion AI — Unified Computer Vision Perception Engine           ║
║                                                                              ║
║   Multi-Modal Vision Pipeline for Intelligent Scene Understanding            ║
║   Classical CV  ×  Deep Learning  ×  Real-Time Video Processing              ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage
-----
    python main.py --mode webcam
    python main.py --mode video  --source path/to/video.mp4
    python main.py --mode image  --source path/to/image.jpg
    python main.py --mode webcam --config configs/my_experiment.yaml
    python main.py --mode webcam --disable edge motion

Keyboard Controls (live mode)
------------------------------
    Q / ESC  — quit
    e        — toggle edge detection
    f        — toggle face detection
    m        — toggle motion detection
    o        — toggle object detection
    c        — toggle contour analysis
    n        — toggle CNN classifier
    t        — toggle tracking
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Ensure project root is importable from any working directory
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from utils.config_loader import ConfigLoader
from utils.logger        import get_logger
from pipelines.perception_pipeline import PerceptionPipeline

logger = get_logger("visionfusion.main")

BANNER = r"""
 __   ___     _    _          _____           _             _    ___ 
 \ \ / (_)___(_)__(_)_ __    |  ___|   _ ___ (_) ___  _ __ / \  |_ _|
  \ V /| / __| / _ \ | '_ \  | |_ | | | / __| |/ _ \| '_ / _ \  | | 
   | | | \__ \ |  __/ | | | | |  _|| |_| \__ \ | (_) | | | / ___ \ | | 
   |_| |_|___/_|\___|_|_| |_| |_|   \__,_|___/_|\___/|_| /_/   \_\___|

  Unified Computer Vision Perception Engine  |  VisionFusion-AI v1.0
"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="VisionFusion AI — Multi-Modal Computer Vision Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--mode", choices=["webcam", "video", "image"],
        default="webcam",
        help="Input mode (default: webcam)",
    )
    parser.add_argument(
        "--source",
        default=None,
        help="Camera index (int) or path to video/image file",
    )
    parser.add_argument(
        "--config",
        default=str(PROJECT_ROOT / "configs" / "default.yaml"),
        help="Path to YAML configuration file",
    )
    parser.add_argument(
        "--no-display",
        action="store_true",
        help="Run headless (no cv2.imshow window)",
    )
    parser.add_argument(
        "--max-frames",
        type=int,
        default=None,
        help="Maximum frames to process (useful for benchmarking)",
    )
    parser.add_argument(
        "--disable",
        nargs="+",
        choices=["edge", "face", "motion", "objects", "contour", "cnn", "track"],
        default=[],
        help="Disable specific pipeline modules",
    )
    parser.add_argument(
        "--enable",
        nargs="+",
        choices=["edge", "face", "motion", "objects", "contour", "cnn", "track"],
        default=[],
        help="Force-enable specific pipeline modules",
    )
    return parser.parse_args()


def resolve_source(mode: str, source_arg: str | None) -> int | str:
    """Determine the capture source from mode and CLI argument."""
    if mode == "webcam":
        if source_arg is None:
            return 0
        try:
            return int(source_arg)
        except ValueError:
            return source_arg
    if source_arg is None:
        logger.error("--source is required for mode '%s'.", mode)
        sys.exit(1)
    return source_arg


def main() -> None:
    print(BANNER)
    args = parse_args()

    # ── Load configuration ─────────────────────────────────────────────
    cfg = ConfigLoader.load(args.config)

    # Apply mode override from CLI
    cfg["input"]["mode"] = args.mode

    # ── Build pipeline ─────────────────────────────────────────────────
    pipeline = PerceptionPipeline(cfg)

    # Apply module enable / disable flags from CLI
    for mod in args.disable:
        pipeline.toggle_module(mod, False)
        logger.info("Module '%s' disabled via CLI.", mod)
    for mod in args.enable:
        pipeline.toggle_module(mod, True)
        logger.info("Module '%s' enabled via CLI.", mod)

    # ── Resolve source ─────────────────────────────────────────────────
    source = resolve_source(args.mode, args.source)

    # ── Run ────────────────────────────────────────────────────────────
    logger.info("Starting VisionFusion AI  [mode=%s  source=%s]",
                args.mode, source)
    pipeline.start(
        mode=args.mode,
        source=source,
        display=not args.no_display,
        max_frames=args.max_frames,
    )

    logger.info("VisionFusion AI session ended.")
    logger.info(pipeline.latency_summary)


if __name__ == "__main__":
    main()

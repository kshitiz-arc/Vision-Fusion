"""VisionFusion AI — utility helpers."""
